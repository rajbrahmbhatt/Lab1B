﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lab1.Models
{
    public class Member
    {
        [Required]
        public String FirstName { get; set; }

        [Required]
        public String LastName { get; set; }

        [Required]
        public String UserName { get; set; }

        [Key]
        [Required]
        [EmailAddress]
        public String Email { get; set; }

        public String Company { get; set; }

        public String Position { get; set; }

        public int BirthDate { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lab1.Models
{
    public class Car
    {
        [Key]
        [Required]
        public int ID { get; set; }

        [Required]
        public String Make { get; set; }

        [Required]
        public String Model { get; set; }

        [Required]
        public int Year { get; set; }

        [Required]
        public int VIN { get; set; }

        public String Color { get; set; }

        public int DealershipID { get; set; }
    }
}

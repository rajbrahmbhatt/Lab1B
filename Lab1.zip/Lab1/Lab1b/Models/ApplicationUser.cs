﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace Lab1b.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        [Required]
        public String FirstName { get; set; }

        [Required]
        public String LastName { get; set; }

        public String Company { get; set; }

        public String Position { get; set; }

        [Required]
        public int BirthDate { get; set; }
    }
}

